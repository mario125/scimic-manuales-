package pe.main;

import pe.threads.TestRunnable;

public class Exec {

	public static void main(String[] args) throws Exception {
			String ruc = "20551093035";
			String accessKey = "bb4a5f128236e5cf1ec5e09e82e3b54ab1a106271cf041d315849e0560594231";
			String ticket = "";
			
			String Consulta ="";
			String pathDocs = "/home/ffalcon/Documentos/ODIN/XML/Nota de debito/Gravada/";
			String pathReport = "/Fernando/ND-ASOCIATE-INVOICE.csv";
			Thread thread = new Thread(new TestRunnable(ruc,accessKey,pathDocs,pathReport,ticket,Consulta));
			thread.start();
	}
}