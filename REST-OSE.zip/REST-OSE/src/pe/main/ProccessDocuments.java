package pe.main;


public class ProccessDocuments {

	public static void main(String[] args) throws Exception {
//		// TODO Auto-generated method stub
//		String ruc = "20551093035";
//		String accessKey = "75767ad79fb8b343d2870ac3a4e65e84a5e3bdf134b3e4e603c335452e344b79";
//		String pathDocs = "/home/adiaz/Escritorio/PROD-OSE-EFACT/DOCUMENTOS/NC/PREPARADOS/";
//		
//		OseGeneralBean oseBean = new OseGeneralBean("https://ose.efact.pe/api-efact-ose/oauth/token", 
//													"https://ose.efact.pe/api-efact-ose/v1/document/",
//													"https://ose.efact.pe/api-efact-ose/v1/cdr/");
//		
//		Thread thread = new Thread(new RestFlowThread(ruc,accessKey,pathDocs,oseBean));
//		thread.start();
	}

}
